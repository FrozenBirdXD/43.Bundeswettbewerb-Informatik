Jede Datei beschreibt einen Gang zu einem Grabmal und ist so aufgebaut:

- 1. Zeile: Anzahl n der Quader im Gang.
- Die folgenden n Zeilen: Die ganzzahlige Periode jedes Quaders.

Hier eine Beispieleingabe:

3
7
1
8

In diesem Beispiel befinden sich 3 Quader im Gang. Der erste Quader hat die Periode 7 Minuten, der zweite 1 Minute und der dritte 8 Minuten.

Hinweise zu den Eingaben:

Die Datei grabmal0.txt entspricht dem Beispiel aus der Aufgabenstellung.

Für die Eingabe grabmal5.txt benötigt dein Programm eventuell mehr Zeit als für die anderen. Versuche, diese Zeit zu minimieren.
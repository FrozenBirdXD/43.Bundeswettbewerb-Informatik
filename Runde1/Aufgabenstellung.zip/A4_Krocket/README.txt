Jede Datei beschreibt eine Toraufstellung und ist so aufgebaut:

- 1. Zeile: Anzahl der Tore n und Radius des Balles r.
- Folgende n Zeilen: Koordinaten der Endpunkte jeweils eines Tores.

Hier eine Beispieleingabe:

2 7
10 20 30 40
12 31 11 8

In dem Beispiel stehen insgesamt zwei Tore im Garten und der Ball hat einen Radius von 7cm. Die Tore sind Strecken mit den Endpunkten für Tor 1: (10|20) und (30|40) sowie für Tor 2: (12|31) und (11|8).
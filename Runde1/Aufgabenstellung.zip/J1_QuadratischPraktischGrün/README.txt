Jede Datei beschreibt eine Planungsaufgabe und ist so aufgebaut:

- 1. Zeile: Anzahl der Interessenten.
- 2. Zeile: Höhe des Grundstücks in Metern.
- 3. Zeile: Breite des Grundstücks in Metern.

Hier ist eine Beispieleingabe:

35
10
20

In diesem Beispiel muss das 10m x 20m große Grundstück in mindestens 35, aber höchstes 10% mehr (also höchstens 38) rechteckige Kleingärten aufgeteilt werden.

Eine Aufteilung in deckungsgleiche Rechtecke für die Kleingärten reicht aus.

Die Datei garten0.txt entspricht dem Beispiel aus der Aufgabenstellung.

Zusätzlich haben wir für euch eine Blockly-Umgebung (https://bwinf.de/mehr-informatik/lernen/programmieren-lernen/blockly/), mit der ihr diese Aufgabe bearbeiten könnt.
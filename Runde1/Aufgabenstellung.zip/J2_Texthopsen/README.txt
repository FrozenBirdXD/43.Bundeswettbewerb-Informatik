Jede Datei enthält einen Text, mit dem Bela und Amira Texthopsen spielen.

Zeichen, die nicht in der Tabelle stehen, werden übersprungen. Das gilt auch, wenn sie am Anfang des Textes stehen.

Zusätzlich haben wir für euch eine Blockly-Umgebung (https://bwinf.de/mehr-informatik/lernen/programmieren-lernen/blockly/), mit der ihr diese Aufgabe bearbeiten könnt.
module com.aufgabe1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    exports com.aufgabe1;
}

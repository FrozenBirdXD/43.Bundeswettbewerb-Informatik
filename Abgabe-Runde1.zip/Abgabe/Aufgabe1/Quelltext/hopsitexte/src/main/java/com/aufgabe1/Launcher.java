package com.aufgabe1;

import javafx.application.Application;

//
//
// Requires JavaFX JDK and Java JDK
//
//

// Launches Main Application
public class Launcher {
    public static void main(String[] args) {
        Application.launch(Main.class, args);
    }
}
